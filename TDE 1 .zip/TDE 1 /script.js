/* CALCULADORA */
const num1 = document.getElementById("num1");
const num2 = document.getElementById("num2");
const operacao = document.getElementById("operacao");
const msg = document.getElementById("msg");

function calcular() {
    const valor1 = Number(num1.value);
    const valor2 = Number(num2.value);
    const tipo = operacao.value;
    let resultado;

    switch (tipo) {
        case "somar":
            resultado = valor1 + valor2;
            break;
        case "subtrair":
            resultado = valor1 - valor2;
            break;
        case "multiplicar":
            resultado = valor1 * valor2;
            break;
        case "dividir":
            if (valor2 === 0) {
                msg.textContent = "Erro: divisão por zero!";
                return;
            }
            resultado = valor1 / valor2;
            break;
        default:
            resultado = "Operação inválida!";
    }

    msg.textContent = "O resultado é: " + resultado;
}   

/*LISTA DE COMPRAS*/
const itemInput = document.getElementById("item");
const lista = document.getElementById("lista");

const adicionarItem = () => {
    const item = itemInput.value.trim();
    if (item === "") {
        alert("Digite um item antes de adicionar!");
        return;
    }

    const li = document.createElement("li");
    li.textContent = item;
    lista.appendChild(li);
    itemInput.value = "";
};

const limparLista = () => lista.innerHTML = "";

/* LISTA DE AFAZERES */
const tarefaInput = document.getElementById("tarefa");
const lista2 = document.getElementById("lista2");
const btnAdicionar = document.getElementById("adicionar");
const btnLimpar = document.getElementById("limpar");

let tarefas = [];

function atualizarLista(callback) {
    lista2.innerHTML = "";
    tarefas.forEach(function(tarefa, index) {
        const li = document.createElement("li");
        li.textContent = tarefa;

        li.onclick = function() {
            li.classList.toggle("concluida");
        };

        lista2.appendChild(li);
    });

    if (callback) callback();
}

btnAdicionar.onclick = function() {
    const tarefa = tarefaInput.value.trim();
    if (tarefa === "") {
        alert("Digite uma tarefa!");
        return;
    }

    tarefas.push(tarefa);

    atualizarLista(function() {
        console.log("Tarefa adicionada: " + tarefa);
    });

    tarefaInput.value = "";
};
btnLimpar.onclick = function() {
    tarefas = [];
    atualizarLista(function() {
        console.log("Lista limpa!");
    });
};


